<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Validator;
use Auth;
use DB;

class UserController extends Controller
{
    public function register(Request $request){
        // validation
        $validator = Validator::make($request->all(),[
            'phone' => 'required|unique:users',
            'password' => 'required',
        ]);

        if($validator->fails()){
            $response = [
                'success' => false,
                'message' => $validator->errors()
            ];
            return response()->json($response, 400);
        }

        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        $user = User::create([
            'phone' => $input['phone'],
            'password' => $input['password'],
            'refer_code' => rand(100000, 999999),
            'bal' => "10",
        ]);

        $success['token'] = $user->createToken('MyApp')->plainTextToken;

        $response = [
            'success' => true,
            'data' => $success,
            'message' => 'User register successfully',
            'user' => $user,
        ];

        return response()->json($response,200);

    }

    public function login(Request $request){
        if(Auth::attempt(['phone'=>$request->phone,'password'=>$request->password])){
            $user = Auth::user();
            $success['token'] = $user->createToken('MyApp')->plainTextToken;

            $response = [
                'success' => true,
                'data' => $success,
                'message' => 'User login successfully',
                'user' => $user,
            ];
            return response()->json($response,200);
        }else{
            $response = [
                'success' => false,
                'message' => 'Unauthorised'
            ];
            return response()->json($response);
        }
    }

    public function getuser(Request $request){
        $input = $request->all();
        $token = $input['token'];
        $id = DB::table('personal_access_tokens')->where('id', $token)->first();
        $user = User::where('id', $id)->first();
        return response()->json($user);
    }
}
